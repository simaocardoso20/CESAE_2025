package Cores;

import Tools.FileTools;

import java.io.FileNotFoundException;

public class MainAscii {
    public static void main(String[] args) throws FileNotFoundException {

        FileTools.printFile("AsciiFiles/IndianaJones.txt");
    }
}
